SELECT * FROM walmart_db.`walmartsales dataset`;

-- Task 1: Identifying the Top Branch by Sales Growth Rate

WITH monthly_sales AS (
    SELECT Branch, City,
           SUBSTRING(Date, 4, 2) AS Month,
           SUBSTRING(Date, 7, 4) AS Year,
           SUM(Total) AS Total_Sales
    FROM walmart_db.`walmartsales_dataset`
    GROUP BY Branch, City, SUBSTRING(Date, 4, 2), SUBSTRING(Date, 7, 4)
)
SELECT m.*,
       LAG(Total_Sales) OVER (PARTITION BY Branch ORDER BY Year, Month) AS Previous_Month_Sales,
       (Total_Sales - LAG(Total_Sales) OVER (PARTITION BY Branch ORDER BY Year, Month)) /
       NULLIF(LAG(Total_Sales) OVER (PARTITION BY Branch ORDER BY Year, Month), 0) * 100 AS Growth_Rate_Percentage
FROM monthly_sales m
ORDER BY Branch, Year, Month;


-- Task 2: Most Profitable Product Line for Each Branch

WITH ProductLineProfits AS (
    SELECT Branch, `Product line`, SUM(`gross income`) AS TotalProfit,
           RANK() OVER (PARTITION BY Branch ORDER BY SUM(`gross income`) DESC) AS ProfitRank
    FROM walmart_db.`walmartsales_dataset`
    GROUP BY Branch, `Product line`
)
SELECT Branch, `Product line` AS MostProfitableProductLine, TotalProfit
FROM ProductLineProfits
WHERE ProfitRank = 1
ORDER BY Branch;


-- Task 3: Customer Segmentation Based on Spending

WITH CustomerSpending AS (
    SELECT `Customer ID` AS CustomerID, SUM(Total) AS TotalSpending
    FROM walmart_db.`walmartsales_dataset`
    GROUP BY `Customer ID`
),
RankedSpending AS (
    SELECT *, NTILE(3) OVER (ORDER BY TotalSpending DESC) AS SpendTier
    FROM CustomerSpending
)
SELECT CustomerID, TotalSpending,
       CASE
           WHEN SpendTier = 1 THEN 'High'
           WHEN SpendTier = 2 THEN 'Medium'
           ELSE 'Low'
       END AS SpendingTier
FROM RankedSpending
ORDER BY TotalSpending DESC;


-- Task 4: Detecting Anomalies in Sales Transactions

WITH ProductLineStats AS (
    SELECT `Product line`, AVG(`Total`) AS avg_total, STDDEV(`Total`) AS stdev_total
    FROM walmart_db.`walmartsales_dataset`
    GROUP BY `Product line`
)
SELECT s.`Invoice ID`, s.Branch, s.City, s.`Product line`, s.`Unit price`, s.Quantity, s.Total,
       p.avg_total AS avg_product_line_total,
       CASE
           WHEN s.Total > p.avg_total + (2 * p.stdev_total) THEN 'High Outlier'
           WHEN s.Total < p.avg_total - (2 * p.stdev_total) THEN 'Low Outlier'
           ELSE 'Normal'
       END AS AnomalyType
FROM walmart_db.`walmartsales_dataset` s
JOIN ProductLineStats p ON s.`Product line` = p.`Product line`
WHERE s.Total > p.avg_total + (2 * p.stdev_total)
   OR s.Total < p.avg_total - (2 * p.stdev_total)
ORDER BY s.`Product line`, ABS(s.Total - p.avg_total) DESC;

-- Task 5: Most Popular Payment Method by City

WITH PaymentCounts AS (
    SELECT City, Payment, COUNT(*) AS PaymentCount,
           RANK() OVER (PARTITION BY City ORDER BY COUNT(*) DESC) AS PaymentRank
    FROM walmart_db.`walmartsales_dataset`
    GROUP BY City, Payment
)
SELECT City, Payment AS MostPopularPayment, PaymentCount
FROM PaymentCounts
WHERE PaymentRank = 1
ORDER BY City;


-- Task 6: Monthly Sales Distribution by Gender

SELECT SUBSTRING(Date, 4, 2) AS Month, Gender,
       SUM(Total) AS Total_Sales,
       COUNT(*) AS Number_of_Transactions,
       ROUND(AVG(Total), 2) AS Average_Sale
FROM walmart_db.`walmartsales_dataset`
GROUP BY SUBSTRING(Date, 4, 2), Gender
ORDER BY Month, Gender;

-- Task 7: Best Product Line by Customer Type

SELECT `Customer type`, `Product line`,
       SUM(Quantity) AS TotalQuantity,
       SUM(Total) AS TotalRevenue,
       COUNT(*) AS NumberOfTransactions,
       AVG(Rating) AS AverageRating
FROM walmart_db.`walmartsales_dataset`
GROUP BY `Customer type`, `Product line`
ORDER BY `Customer type`, TotalQuantity DESC;

-- Task 8: Identifying Repeat Customers

SELECT a.`Customer ID` AS customer_id,
       COUNT(DISTINCT a.`Invoice ID`) AS total_purchases,
       MIN(DATEDIFF(STR_TO_DATE(b.`Date`, '%d-%m-%Y'), STR_TO_DATE(a.`Date`, '%d-%m-%Y'))) AS min_days_between_purchases
FROM walmart_db.`walmartsales_dataset` a
JOIN walmart_db.`walmartsales_dataset` b
  ON a.`Customer ID` = b.`Customer ID`
 AND a.`Invoice ID` <> b.`Invoice ID`
 AND STR_TO_DATE(a.`Date`, '%d-%m-%Y') < STR_TO_DATE(b.`Date`, '%d-%m-%Y')
 AND DATEDIFF(STR_TO_DATE(b.`Date`, '%d-%m-%Y'), STR_TO_DATE(a.`Date`, '%d-%m-%Y')) <= 30
GROUP BY a.`Customer ID`
ORDER BY min_days_between_purchases;

-- Task 9: Top 5 Customers by Sales Volume

SELECT `Customer ID`, SUM(`Total`) AS TotalRevenue
FROM walmart_db.`walmartsales_dataset`
GROUP BY `Customer ID`
ORDER BY TotalRevenue DESC
LIMIT 5;

-- Task 10: Sales Trends by Day of the Week

SELECT 
    CASE DAYOFWEEK(STR_TO_DATE(`Date`, '%d-%m-%Y'))
        WHEN 1 THEN 'Sunday'
        WHEN 2 THEN 'Monday'
        WHEN 3 THEN 'Tuesday'
        WHEN 4 THEN 'Wednesday'
        WHEN 5 THEN 'Thursday'
        WHEN 6 THEN 'Friday'
        WHEN 7 THEN 'Saturday'
    END AS day_of_week,
    COUNT(*) AS transaction_count,
    SUM(Total) AS total_sales,
    AVG(Total) AS average_sale
FROM
    walmart_db.`walmartsales_dataset`
GROUP BY day_of_week
ORDER BY total_sales DESC;
